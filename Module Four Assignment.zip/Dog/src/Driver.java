public class Driver {
	public static void main(String[] args) {
		Dog method = new Dog();
		method.setTopTrick("ringing the bell to go outside.");
		method.toString();
	}
}