public class Dog {

	private String type;
	private String breed;
	private String name;
	private String topTrick;

	public Dog() {
		type = "DogType";
		breed = "DogBreed";
		name = "DogName";
	}

	public void setTopTrick(String DogTrick) {
		topTrick = DogTrick;
	}

	public String getTopTrick() {
		return topTrick;
	}

	public String toString() {
		String temp = "\nDOG DATA\n" + name + " is a " + breed + ", a " + type + " dog. \nThe top trick is : "
				+ topTrick + ".";
		return temp;
	}

	public class Corgi extends Dog {

		private int weight;
		private int age;

		public Corgi() {
			weight = 0;
			age = 0;
		}

		public void setWeight(int CorgiWeight) {
			weight = CorgiWeight;
		}

		public void setAge(int CorgiAge) {
			age = CorgiAge;
		}

		public String toString() {
			return (super.toString() + "\nThe Corgi is " + age + " years old and weighs " + weight + " pounds.");
		}
	}
}