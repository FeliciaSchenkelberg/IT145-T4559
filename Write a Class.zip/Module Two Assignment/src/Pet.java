
public class Pet {

	private String petType;
	private String petName;
	private int petAge;
	private boolean dogSpace;
	private boolean catSpace;
	private int daysStay;
	private double amountDue;
	
	public Pet(String petType, String petName, int petAge, boolean dogSpace, boolean catSpace, int daysStay, double amountDue) {
		setPetType(petType);
		setpetName(petName);
		setpetAge(petAge);
		setdogSpace(30);
		setcatSpace(12);
		setdaysStay(daysStay);
	}
		
	public string getPetType() {
		return petType;
	}
	
	public void set PetType(string PetType) {
		this.PetType = PetType;
	}
	
	public string getpetName() {
		return petName;
	}
	
	public void set petName(string petName) {
		this.petName = petName;
	}
	
	public int getpetAge() {
		return petAge;
	}
	
	public void set petAge(int petAge) {
		this.petAge = petAge;
	}
	
	private boolean getdogSpace() {
		return dogSpace;
	}
	
	public void set dogSpace(boolean dogSpace) {
		this.dogSpace = dogSpace;
	}
	private boolean getcatSpace() {
		return catSpace;
	}
	
	public void set catSpace(boolean catSpace) {
		this.catSpace = catSpace;
	}
	
	public int getdaysStay() {
		return daysStay;
	}
	
	public void set daysStay(int daysStay) {
		this.daysStay = daysStay;
	}
	
	private double getamountDue() {
		return amountDue()
	}
	
	public void set amountDue(double amountDue) {
		this.amountDue = amountDue;
	}
	
	
	public void checkIn() {}
	public void checkIn() {}
	public void checkout() {}
	public void getPet() {}
	public void createPet() {}
	public void updatePet() {}
	
	class Cat {
		public void catSpaceNbr() {
			
			private boolean getcatSpaceNbr() {
				return catSpaceNbr()
			}
			
			public void set catSpaceNbr(double catSpaceNbr) {
				this.catSpaceNbr = catSpaceNbr;
			}
			
		}
	}

}
